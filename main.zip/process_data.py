"""
process_data.py - Macro logic replacement for data cleaning and transformation
Processes eCW report and template file, applies filters, and generates HealthX import file.
"""
import pandas as pd
import os
from datetime import datetime
from typing import List, Tuple
import json

def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Strip whitespace from headers to avoid fragile ' leading space' issues."""
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df

def _find_col(df: pd.DataFrame, candidates: list[str]) -> str | None:
    """Return the first matching column by case-insensitive exact or contains match."""
    cols = {str(c).strip(): c for c in df.columns}
    lower_map = {k.lower(): v for k, v in cols.items()}
    for cand in candidates:
        key = cand.strip().lower()
        if key in lower_map:
            return lower_map[key]
    # contains match
    for want in candidates:
        w = want.strip().lower()
        for k, v in lower_map.items():
            if w in k:
                return v
    return None

def _load_cfg_paths() -> tuple[str, str, str]:
    """Load folder paths from config.json."""
    base = os.getcwd()
    cfg_path = os.path.join(base, "config.json")
    input_folder = "inputs"
    output_folder = "outputs"
    log_folder = "logs"
    try:
        with open(cfg_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        input_folder = cfg.get("input_folder", input_folder)
        output_folder = cfg.get("output_folder", output_folder)
        log_folder = cfg.get("log_folder", log_folder)
    except Exception:
        pass
    in_dir = os.path.join(base, input_folder)
    out_dir = os.path.join(base, output_folder)
    log_dir = os.path.join(base, log_folder)
    for d in (in_dir, out_dir, log_dir):
        os.makedirs(d, exist_ok=True)
    return in_dir, out_dir, log_dir


def _read_excel_auto(path: str, sheet_name=None) -> pd.DataFrame:
    """Read .xlsx/.xlsm with openpyxl and .xls with xlrd 1.2.0.
    Falls back to pandas default if engine selection fails.
    """
    ext = os.path.splitext(str(path).lower())[1]
    # Prefer engine by extension, then try the other engine if it fails.
    last_err = None
    if ext == ".csv":
        try:
            return pd.read_csv(path)
        except Exception as e:
            last_err = e
            # Try Excel readers if misnamed
            try:
                return pd.read_excel(path, sheet_name=sheet_name, engine="openpyxl")
            except Exception:
                pass
    if ext in (".xlsx", ".xlsm"):
        try:
            return pd.read_excel(path, sheet_name=sheet_name, engine="openpyxl")
        except Exception as e:
            last_err = e
            # Try generic fallback
            try:
                return pd.read_excel(path, sheet_name=sheet_name)
            except Exception:
                pass
    elif ext == ".xls":
        try:
            return pd.read_excel(path, sheet_name=sheet_name, engine="xlrd")
        except Exception as e:
            last_err = e
            # Some systems mislabel .xlsx as .xls; try openpyxl
            try:
                return pd.read_excel(path, sheet_name=sheet_name, engine="openpyxl")
            except Exception:
                pass
    # Final attempt without engine
    try:
        return pd.read_excel(path, sheet_name=sheet_name)
    except Exception as e:
        # Re-raise with a clearer message
        hint = (
            "If this is an older .xls exported from a web app, open it in Excel and 'Save As' .xlsx, "
            "then try again."
        )
        raise Exception(f"Unable to read Excel file '{path}'. {hint} Original error: {e or last_err}")


def _ensure_logs_dir() -> str:
    """Ensure logs directory exists."""
    _, _, logs_dir = _load_cfg_paths()
    os.makedirs(logs_dir, exist_ok=True)
    return logs_dir


def _log(message: str, log_path: str = None) -> None:
    """Write message to log file with timestamp."""
    if log_path is None:
        logs_dir = _ensure_logs_dir()
        # Use the most recent timestamp-based log file or create new one
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = os.path.join(logs_dir, f"run_{ts}.txt")

    # Append to existing log if created in same second, otherwise create new
    with open(log_path, "a", encoding="utf-8") as f:
        log_ts = datetime.now().strftime("%H:%M:%S")
        f.write(f"[{log_ts}] {message}\n")


def _detect_insurance_columns(df: pd.DataFrame) -> List[str]:
    """Detect all columns that might contain insurance/payor information."""
    cols = []
    for c in df.columns:
        col_lower = str(c).lower()
        if any(keyword in col_lower for keyword in ["payor", "payer", "insurance"]):
            cols.append(c)
    return cols


def _get_visit_type_series(df: pd.DataFrame) -> pd.Series:
    """Extract visit type information from dataframe."""
    candidate_cols = [
        "Visit Type",
        "Appointment Type",
        "Patient Type",
        "Type",
        "Reason",
    ]
    for c in candidate_cols:
        if c in df.columns:
            s = df[c].astype(str).str.lower()
            return s
    # Fallback: treat all as follow-up
    return pd.Series(["follow-up"] * len(df), index=df.index)


def _load_agents_from_config() -> List[str]:
    """Load agent list from config.json."""
    cfg_path = os.path.join(os.getcwd(), "config.json")
    try:
        with open(cfg_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        agents = cfg.get("agents", [])
        if isinstance(agents, list) and agents:
            return [str(a) for a in agents]
    except Exception:
        pass
    # Default to 8 agents
    return [f"Agent_{i}" for i in range(1, 9)]


def _assign_agents_preserve_order(df: pd.DataFrame, provider_col: str, agents: List[str]) -> List[str]:
    """Assign agents by provider without changing row order.
    Keeps same provider mapped to the same agent; round-robins otherwise.
    """
    if not agents:
        agents = [f"Agent_{i}" for i in range(1, 9)]
    provider_to_agent: dict = {}
    agent_index = 0
    assigned: List[str] = []
    providers = df[provider_col] if provider_col in df.columns else [None] * len(df)
    for prov in providers:
        if prov in provider_to_agent:
            assigned.append(provider_to_agent[prov])
        else:
            a = agents[agent_index % len(agents)]
            provider_to_agent[prov] = a
            assigned.append(a)
            agent_index += 1
    return assigned


def _assign_priority_and_agents(df: pd.DataFrame, provider_col: str, agents: List[str]) -> pd.DataFrame:
    """Assign allocation priority and agents to records."""
    df = df.copy()

    # Determine NP/FU buckets from visit type
    visit_type = _get_visit_type_series(df)
    is_new = visit_type.str.contains("new", case=False, na=False)
    bucket = pd.Series(["FU"] * len(df), index=df.index)
    bucket[is_new] = "NP"

    df["Allocation Group"] = bucket

    # Sort within buckets
    sort_cols = []
    if provider_col and provider_col in df.columns:
        sort_cols.append(provider_col)
    for c in ("Appointment Date", "Appointment Location", "Date", "Location"):
        if c in df.columns:
            sort_cols.append(c)

    # Sort: NP first, then FU
    df = pd.concat([
        df[df["Allocation Group"] == "NP"],
        df[df["Allocation Group"] == "FU"],
    ], axis=0)
    
    if sort_cols:
        df = df.sort_values(by=["Allocation Group"] + sort_cols, kind="stable")

    # Allocation Priority numbering per bucket
    priorities = []
    counters = {"NP": 0, "FU": 0}
    for _, row in df.iterrows():
        g = row.get("Allocation Group", "FU")
        counters[g] += 1
        priorities.append(f"{g}-{counters[g]:03d}")
    df["Allocation Priority"] = priorities

    # Agent distribution: try to keep same provider with same agent
    if not agents:
        agents = _load_agents_from_config()

    agent_assignments = []
    provider_to_agent = {}
    agent_index = 0

    providers = df[provider_col] if provider_col and provider_col in df.columns else pd.Series([None] * len(df), index=df.index)
    for prov in providers:
        if prov and prov in provider_to_agent:
            agent_assignments.append(provider_to_agent[prov])
        else:
            chosen = agents[agent_index % len(agents)]
            agent_assignments.append(chosen)
            if prov:
                provider_to_agent[prov] = chosen
            agent_index += 1
    df["Assigned Agent"] = agent_assignments

    return df


def generate_healthx_import(ecw_report_path: str, template_path: str, log_path: str = None) -> Tuple[str, int]:
    """Load, filter, sort, and export files according to macro and mapping rules."""
    _log(
        f"Start processing. eCW='{os.path.basename(ecw_report_path)}', template='{os.path.basename(template_path)}'",
        log_path=log_path,
    )

    if not os.path.isfile(ecw_report_path):
        raise FileNotFoundError(f"eCW report not found: {ecw_report_path}")
    if not os.path.isfile(template_path):
        raise FileNotFoundError(f"Template not found: {template_path}")

    # Read eCW report
    _log("Loading eCW report...", log_path=log_path)
    df = _read_excel_auto(ecw_report_path)
    df = _normalize_columns(df)
    original_rows = len(df)
    _log(f"Loaded {original_rows} rows from eCW report", log_path=log_path)

    # Load Help sheet
    _log("Loading Help sheet for lookup rules...", log_path=log_path)
    try:
        help_df = _read_excel_auto(template_path, sheet_name="Help")
        help_df = _normalize_columns(help_df)
        _log(f"Loaded Help sheet with {len(help_df)} rows", log_path=log_path)
    except Exception as e:
        _log(
            f"Warning: Could not load Help sheet: {e}. Continuing without Help sheet lookups.",
            log_path=log_path,
        )
        help_df = None

    # Filter 1: Appointment State exists in Help
    appt_state_col = _find_col(df, ["Appointment State", "Appointment Location", "Location", "State"])
    help_state_col = _find_col(help_df, ["Appointment State"]) if help_df is not None else None
    if help_df is not None and appt_state_col and help_state_col and help_state_col in help_df.columns:
        before_filter = len(df)
        valid_states = set(help_df[help_state_col].dropna().astype(str).str.strip().unique())
        df = df[df[appt_state_col].astype(str).str.strip().isin(valid_states)]
        _log(
            f"Filter 1 (Appointment State in Help sheet): {before_filter} -> {len(df)} rows",
            log_path=log_path,
        )
    else:
        _log(
            "Filter 1 skipped: Help sheet or Appointment State column not found",
            log_path=log_path,
        )

    # Dual Validation: Do not delete rows for Workable N; only warn
    visit_type_col = _find_col(df, ["Visit Type", "Appointment Type", "Type"])
    help_visit_col = _find_col(help_df, ["Visit Type", "Visit Type Workable Y / N"]) if help_df is not None else None
    help_workable_col = _find_col(help_df, ["Workable status", "Workable  status", "Workable"])
    warnings_dir = os.path.join(_load_cfg_paths()[1], "..", "outputs", "warnings")  # ensure path under outputs/
    try:
        # compute real outputs dir robustly
        _, outputs_dir, _ = _load_cfg_paths()
        warnings_dir = os.path.join(outputs_dir, "warnings")
    except Exception:
        pass
    os.makedirs(warnings_dir, exist_ok=True)

    if help_df is not None and visit_type_col and help_visit_col and help_workable_col:
        workable_map = {}
        for _, r in help_df[[help_visit_col, help_workable_col]].dropna().iterrows():
            workable_map[str(r[help_visit_col]).strip()] = str(r[help_workable_col]).strip().upper()
        n_visit_types = {k for k, v in workable_map.items() if v == "N"}
        if n_visit_types:
            mask_n = df[visit_type_col].astype(str).str.strip().isin(n_visit_types)
            bad = df[mask_n]
            if not bad.empty:
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                fp = os.path.join(warnings_dir, f"workable_flagged_N_{ts}.csv")
                bad.to_csv(fp, index=False)
                _log(f"Dual validation warning: {len(bad)} rows with Visit Type flagged N. Wrote {fp}", log_path=log_path)
    else:
        _log("Dual validation skipped for Workable N: missing Help or columns", log_path=log_path)

    # Filter 3: Exclude insurance codes
    excluded_codes = ["L105", "L107", "L109C", "L109Q", "L109W"]
    primary_ins_col = _find_col(df, ["Primary Insurance Name", "Primary Insurance"])
    if primary_ins_col:
        # Warn on excluded names; keep current deletion for codes to preserve previous behavior
        if help_df is not None:
            try:
                help_excl_col = _find_col(help_df, ["Excluded Primary Insurance Name", "Primary Insurance Name"])
                if help_excl_col:
                    excluded_names = set(str(x).strip() for x in help_df[help_excl_col].dropna().tolist())
                    mask_names = df[primary_ins_col].astype(str).str.strip().isin(excluded_names)
                    bad2 = df[mask_names]
                    if not bad2.empty:
                        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                        fp = os.path.join(warnings_dir, f"primary_insurance_warnings_{ts}.csv")
                        bad2.to_csv(fp, index=False)
                        _log(f"Dual validation warning: {len(bad2)} rows with excluded Primary Insurance. Wrote {fp}", log_path=log_path)
            except Exception:
                pass
        before_filter = len(df)
        mask_excluded = df[primary_ins_col].astype(str).str.strip().isin(excluded_codes)
        for code in excluded_codes:
            mask_excluded = mask_excluded | df[primary_ins_col].astype(str).str.contains(code, case=False, na=False)
        df = df[~mask_excluded]
        _log(f"Filter 3 (Excluded insurance codes {excluded_codes}): {before_filter} -> {len(df)} rows", log_path=log_path)

    # Optional Visit Status
    if "Visit Status" in df.columns:
        before_filter = len(df)
        vs = df["Visit Status"].astype(str)
        df = df[vs.str.contains("PEN", case=False, na=False) | vs.str.contains("PR :", case=False, na=False)]
        if len(df) < before_filter:
            _log(
                f"Optional Visit Status filter (PEN/PR): {before_filter} -> {len(df)} rows",
                log_path=log_path,
            )

    # Remove empty rows
    before_filter = len(df)
    df = df.dropna(how="all")
    _log(f"Removed empty rows: {before_filter} -> {len(df)} rows", log_path=log_path)

    # ---------- Sorting & Allocation ----------
    provider_col = None
    for col_name in ["Appointment Provider Name", "Provider Name", "Provider"]:
        if col_name in df.columns:
            provider_col = col_name
            break

    # Mark NP/FU
    vt_series = df[visit_type_col].astype(str).str.lower() if visit_type_col and visit_type_col in df.columns else pd.Series([""] * len(df))
    is_np = vt_series.str.contains("np") | vt_series.str.contains("new")
    df["Allocation Group"] = ["NP" if v else "FU" for v in is_np]

    # NP group
    np_df = df[df["Allocation Group"] == "NP"].copy()
    fu_df = df[df["Allocation Group"] == "FU"].copy()

    np_sort_cols: list[str] = []
    if "Appointment Date" in np_df.columns:
        np_sort_cols.append("Appointment Date")
    if provider_col and provider_col in np_df.columns:
        np_sort_cols.append(provider_col)
    if " Appointment State" in np_df.columns:
        np_sort_cols.append(" Appointment State")
    elif "Appointment State" in np_df.columns:
        np_sort_cols.append("Appointment State")
    if np_sort_cols:
        np_df = np_df.sort_values(by=np_sort_cols, ascending=[True] * len(np_sort_cols), kind="stable")
    if not np_df.empty:
        np_df = np_df.reset_index(drop=True)
        np_df["Sequence Label"] = [f"NP-{i+1:03d}" for i in range(len(np_df))]
        np_df["AgentBucket"] = [((i) % 8) + 1 for i in range(len(np_df))]
        np_df["Allocation Priority"] = np_df["Sequence Label"]

    # FU group
    if not fu_df.empty:
        fu_sort_cols: list[str] = []
        if "Appointment Date" in fu_df.columns:
            fu_sort_cols.append("Appointment Date")
        if provider_col and provider_col in fu_df.columns:
            fu_sort_cols.append(provider_col)
        loc_col = None
        if "Appointment State" in fu_df.columns:
            loc_col = "Appointment State"
        if loc_col:
            fu_sort_cols.append(loc_col)
        if fu_sort_cols:
            fu_df = fu_df.sort_values(by=fu_sort_cols, ascending=[True] * len(fu_sort_cols), kind="stable")
        if loc_col:
            # Robust: use groupby cumcount on a filled location key so lengths always match
            key = fu_df[loc_col].astype(str).fillna("")
            cnt = key.groupby(key).cumcount()
            # Human-readable sequence for QA
            fu_df["Sequence Label"] = ["FU-" + f"{i+1:03d}" for i in cnt]
            fu_df["AgentBucket"] = ((cnt % 8) + 1).astype(int)
            fu_df["Allocation Priority"] = fu_df["Sequence Label"]
            fu_df = fu_df.sort_values(by=[loc_col], kind="stable")
        else:
            fu_df = fu_df.reset_index(drop=True)
            fu_df["Sequence Label"] = [f"FU-{i+1:03d}" for i in range(len(fu_df))]
            fu_df["AgentBucket"] = [((i) % 8) + 1 for i in range(len(fu_df))]
            fu_df["Allocation Priority"] = fu_df["Sequence Label"]

    out_df = pd.concat([np_df, fu_df], axis=0).reset_index(drop=True)
    _log("Assigning agents from AgentBucket mapping...", log_path=log_path)
    if "AgentBucket" not in out_df.columns:
        out_df["AgentBucket"] = [((i) % 8) + 1 for i in range(len(out_df))]
    out_df["Assigned Agent"] = out_df["AgentBucket"].apply(lambda x: f"Agent {int(x)}")
    out_df = out_df.sort_values(["AgentBucket", "Sequence Label"], kind="stable").reset_index(drop=True)
    df = out_df

    # Save outputs
    _, out_dir, _ = _load_cfg_paths()
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    xlsx_path = os.path.join(out_dir, f"HealthX_Import_{ts}.xlsx")
    _log(f"Saving output file: {os.path.basename(xlsx_path)}", log_path=log_path)
    with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Import")

    _log("Building HX CSV using mapping...", log_path=log_path)
    output_columns = [
        "Organization",
        "Primary Insurance Name",
        "Provider Name",
        "Primary Insurance ID",
        "Patient Account Number",
        "Patient Name",
        "DOB",
        "Date of Service",
        "Visit Type",
        "Appointment Location",
        "Appointment Time",
        "Physician NPI",
        "Secondary Insurance Name",
        "Secondary Insurance ID",
        "Tertiary Insurance Name",
        "Tertiary Insurance ID",
        "Allocation Priority",
    ]
    source_map = {
        "Organization": "__STATIC__Audentes_Verification",
        "Primary Insurance Name": "Primary Insurance Name2",
        "Provider Name": "Appointment Provider Name",
        "Primary Insurance ID": "Primary Insurance Subscriber No",
        "Patient Account Number": "Patient Acct No",
        "Patient Name": "Patient Name",
        "DOB": "Patient DOB",
        "Date of Service": "Appointment Date",
        "Visit Type": "Visit Type",
        "Appointment Location": "Appointment State",
        "Appointment Time": "Appointment Start Time",
        "Physician NPI": "Appointment Provider NPI",
        "Secondary Insurance Name": "Secondary Insurance Name",
        "Secondary Insurance ID": "Secondary Insurance Subscriber No",
        "Tertiary Insurance Name": "Tertiary Insurance Name",
        "Tertiary Insurance ID": "Tertiary Insurance Subscriber No",
        "Allocation Priority": "Allocation Priority",
    }

    def _pick(df_in: pd.DataFrame, names: list[str]) -> pd.Series:
        """Pick first existing column by exact name; else empty series."""
        for n in names:
            if n in df_in.columns:
                return df_in[n]
        return pd.Series([""] * len(df_in))

    def _pick_appointment_location(df_in: pd.DataFrame) -> pd.Series:
        """Return Appointment Location robustly by checking multiple variants and fuzzy match."""
        # Common variants (leading/trailing spaces, different label)
        exact_candidates = [
            " Appointment State",
            "Appointment State",
            "Appointment Location",
            " Appointment Location",
        ]
        for c in exact_candidates:
            if c in df_in.columns:
                _log(f"Found Appointment Location source: '{c}'", log_path=log_path)
                return df_in[c]
        # Fallback: Use Patient State (common in eCW reports)
        if "Patient State" in df_in.columns:
            _log("Using 'Patient State' as fallback for Appointment Location", log_path=log_path)
            return df_in["Patient State"]
        # Fuzzy: find a column that contains both 'appointment' and 'state' (case-insensitive)
        lowered = {str(col): str(col).lower().strip() for col in df_in.columns}
        for col, low in lowered.items():
            if "appointment" in low and "state" in low:
                _log(f"Found Appointment Location via fuzzy match: '{col}'", log_path=log_path)
                return df_in[col]
        # Log warning if nothing found
        _log(f"WARNING: Could not find Appointment Location column. Available columns: {list(df_in.columns)[:10]}...", log_path=log_path)
        # As a last resort, return an empty series
        return pd.Series([""] * len(df_in))

    mapped: dict = {}
    for out_col in output_columns:
        src = source_map.get(out_col)
        if src and src.startswith("__STATIC__"):
            mapped[out_col] = pd.Series([src.replace("__STATIC__", "")] * len(df), index=df.index)
        elif out_col == "Primary Insurance Name":
            mapped[out_col] = _pick(df, ["Primary Insurance Name2", "Primary Insurance Name"]).reset_index(drop=True)
        elif out_col == "Appointment Location":
            mapped[out_col] = _pick_appointment_location(df).reset_index(drop=True)
        elif src and src in df.columns:
            mapped[out_col] = pd.Series(df[src]).reset_index(drop=True)
        else:
            mapped[out_col] = pd.Series([""] * len(df), index=df.index)

    # Include AgentBucket for downstream QA if column exists
    if "AgentBucket" in df.columns and "Agent Bucket" not in mapped:
        mapped["Agent Bucket"] = df["AgentBucket"].reset_index(drop=True)
        output_columns.append("Agent Bucket")

    hx_csv_df = pd.DataFrame(mapped, index=df.index)[output_columns]
    csv_date = datetime.now().strftime("%Y%m%d")
    csv_path = os.path.join(out_dir, f"Audentes-Verification-Verification_{csv_date}.csv")
    hx_csv_df.to_csv(csv_path, index=False)
    _log(f"HX CSV saved: {os.path.basename(csv_path)}", log_path=log_path)

    processed = len(df)
    _log(
        f"Completed processing. Input rows={original_rows}, output rows={processed}, xlsx='{os.path.basename(xlsx_path)}', csv='{os.path.basename(csv_path)}'",
        log_path=log_path,
    )
    return csv_path, processed
 


# Alias for backward compatibility
def process_files(ecw_path: str, template_path: str) -> Tuple[str, int]:
    """Alias for generate_healthx_import for backward compatibility."""
    return generate_healthx_import(ecw_path, template_path)
