import argparse
import csv
import os
import sys
import time
import traceback
from datetime import datetime
from typing import Dict, List, Optional, Tuple

try:
	import yaml  # type: ignore
except Exception:
	yaml = None

try:
	import pandas as pd  # type: ignore
except Exception:
	pd = None

# Optional Windows-only Excel COM
try:
	import win32com.client  # type: ignore
except Exception:
	win32com = None


def _now_ts() -> str:
	return datetime.now().strftime("%Y%m%d_%H%M%S")


def _ensure_dirs(paths: Dict) -> Dict:
	out = {}
	for key in ("uploads_dir", "outputs_dir", "logs_dir"):
		val = paths.get(key)
		if not val:
			continue
		os.makedirs(val, exist_ok=True)
		out[key] = os.path.abspath(val)
	return out


def _load_yaml(path: Optional[str]) -> Dict:
	if not path:
		return {}
	if not os.path.isfile(path):
		return {}
	if yaml is None:
		print("WARNING: pyyaml not installed; skipping YAML config load.", file=sys.stderr)
		return {}
	with open(path, "r", encoding="utf-8") as f:
		return yaml.safe_load(f) or {}


def _init_logging(logs_dir: str) -> str:
	os.makedirs(logs_dir, exist_ok=True)
	fp = os.path.join(logs_dir, f"run_{_now_ts()}.log")
	with open(fp, "w", encoding="utf-8") as f:
		f.write(f"[{datetime.now().isoformat(timespec='seconds')}] Run started\n")
	return fp


def _log(log_path: str, msg: str) -> None:
	with open(log_path, "a", encoding="utf-8") as f:
		f.write(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}\n")


def _read_excel_help(workbook_path: str, log_path: str) -> Tuple[Optional["pd.DataFrame"], Optional["pd.DataFrame"]]:
	if pd is None:
		_log(log_path, "ERROR: pandas not installed; cannot read workbook.")
		return None, None
	try:
		help_df = pd.read_excel(workbook_path, sheet_name="Help", engine="openpyxl")
	except Exception as exc:
		_log(log_path, f"WARNING: Could not read Help sheet: {exc}")
		help_df = None
	raw_df = None
	try:
		raw_df = pd.read_excel(workbook_path, sheet_name="Raw", engine="openpyxl")
	except Exception as exc:
		_log(log_path, f"WARNING: Could not read Raw sheet: {exc}")
	return help_df, raw_df


def _normalize_columns(df: "pd.DataFrame") -> "pd.DataFrame":
	df = df.copy()
	df.columns = [str(c).strip() for c in df.columns]
	return df


def _detect_columns(
	df: "pd.DataFrame",
	candidates: List[str]
) -> Optional[str]:
	cols = {c.lower(): c for c in df.columns}
	for cand in candidates:
		cl = cand.lower()
		if cl in cols:
			return cols[cl]
	# loose contains match
	for low, orig in cols.items():
		for cand in candidates:
			if cand.lower() in low:
				return orig
	return None


def _try_run_macro_and_paste_csv(
	workbook_path: str,
	input_csv_path: str,
	log_path: str,
	timeout_seconds: int = 300
) -> bool:
	if win32com is None:
		_log(log_path, "INFO: win32com not available; skipping macro invocation.")
		return False
	try:
		_log(log_path, "Opening Excel via COM to run macro...")
		excel = win32com.client.DispatchEx("Excel.Application")
		excel.Visible = False
		excel.DisplayAlerts = False
		wb = excel.Workbooks.Open(workbook_path)
		try:
			# Paste CSV into Raw sheet (clear then paste)
			raw_sheet = None
			for ws in wb.Worksheets:
				if str(ws.Name).strip().lower() == "raw":
					raw_sheet = ws
					break
			if raw_sheet is None:
				_log(log_path, "WARNING: Raw sheet not found; creating one.")
				raw_sheet = wb.Worksheets.Add()
				raw_sheet.Name = "Raw"
			raw_sheet.Cells.Clear()
			# Load CSV quickly into Raw using QueryTable (fast and robust)
			qt = raw_sheet.QueryTables.Add(
				Connection=f"TEXT;{os.path.abspath(input_csv_path)}",
				Destination=raw_sheet.Range("A1")
			)
			qt.TextFileParseType = 1  # xlDelimited
			qt.TextFileCommaDelimiter = True
			qt.AdjustColumnWidth = True
			qt.Refresh(False)
			# Run macro if present
			try:
				excel.Run("Audentes_Verification_Cleaned")
			except Exception as exc:
				_log(log_path, f"WARNING: Macro run failed or not found: {exc}")
				# still save workbook state
			wb.Save()
		finally:
			# Close Excel cleanly
			wb.Close(SaveChanges=True)
			excel.Quit()
		_log(log_path, "Excel macro path completed.")
		return True
	except Exception as exc:
		_log(log_path, f"ERROR during Excel COM macro flow: {exc}")
		return False


def _dual_validation_and_filters(
	df: "pd.DataFrame",
	help_df: Optional["pd.DataFrame"],
	outputs_dir: str,
	log_path: str
) -> "pd.DataFrame":
	df = _normalize_columns(df)
	if help_df is not None:
		help_df = _normalize_columns(help_df)
	# Identify critical columns
	visit_type_col = _detect_columns(df, ["Visit Type"])
	provider_col = _detect_columns(df, ["Provider Name", "Provider"])
	appt_date_col = _detect_columns(df, ["Appointment Date", "DOS", "Date Of Service"])
	location_col = _detect_columns(df, ["Appointment Location", "Location"])
	patient_acct_col = _detect_columns(df, ["Patient Acct No", "Patient Account No", "Acct No"])
	primary_ins_col = _detect_columns(df, ["Primary Insurance Name", "Primary Insurance"])
	assigned_agent_col = _detect_columns(df, ["Assigned Agent", "AssignedAgent"])

	missing = []
	for name, col in [
		("Visit Type", visit_type_col),
		("Provider Name", provider_col),
		("Appointment Date", appt_date_col),
		("Appointment Location", location_col),
		("Patient Acct No", patient_acct_col),
		("Primary Insurance Name", primary_ins_col),
	]:
		if col is None:
			missing.append(name)
	if missing:
		_log(log_path, f"WARNING: Missing expected columns: {', '.join(missing)}")

	# Build validation sets from Help
	n_visit_types: List[str] = []
	excluded_insurances: List[str] = []

	if help_df is not None:
		# Try to detect mapping columns
		help_visit_type_col = _detect_columns(help_df, ["Visit Type"])
		help_workable_col = _detect_columns(help_df, ["Workable", "Workable status"])
		help_excl_ins_col = _detect_columns(help_df, ["Excluded Primary Insurance Name", "Excluded Insurance", "Primary Insurance Name"])

		if help_visit_type_col and help_workable_col:
			try:
				n_visit_types = [
					str(v).strip()
					for v, w in zip(help_df[help_visit_type_col], help_df[help_workable_col])
					if str(w).strip().upper() == "N"
				]
			except Exception as exc:
				_log(log_path, f"WARNING: Could not build n_visit_types: {exc}")

		if help_excl_ins_col:
			try:
				excluded_insurances = sorted({str(x).strip() for x in help_df[help_excl_ins_col].dropna().tolist() if str(x).strip()})
			except Exception as exc:
				_log(log_path, f"WARNING: Could not build excluded_insurances: {exc}")

	# Dual validation (warn-only)
	ts = _now_ts()
	warn_dir = os.path.join(outputs_dir, "warnings")
	os.makedirs(warn_dir, exist_ok=True)

	if visit_type_col and n_visit_types:
		bad_vt = df[df[visit_type_col].astype(str).str.strip().isin(set(n_visit_types))]
		if not bad_vt.empty:
			fp = os.path.join(warn_dir, f"workable_flagged_N_{ts}.csv")
			bad_vt.to_csv(fp, index=False)
			_log(log_path, f"Dual validation WARNING: {len(bad_vt)} rows with Visit Type marked N. Wrote {fp}")
	if primary_ins_col and excluded_insurances:
		bad_ins = df[df[primary_ins_col].astype(str).str.strip().isin(set(excluded_insurances))]
		if not bad_ins.empty:
			fp = os.path.join(warn_dir, f"primary_insurance_warnings_{ts}.csv")
			bad_ins.to_csv(fp, index=False)
			_log(log_path, f"Dual validation WARNING: {len(bad_ins)} rows with excluded Primary Insurance. Wrote {fp}")

	# Business filters
	orig_count = len(df)
	# Exclude workers comp style payors (heuristic)
	if primary_ins_col:
		mask_wc = df[primary_ins_col].astype(str).str.contains("WORK", case=False, na=False) | \
		          df[primary_ins_col].astype(str).str.contains("COMP", case=False, na=False)
		df = df[~mask_wc].copy()
		_log(log_path, f"Filter: Excluded WC-like payors: {orig_count - len(df)} removed (heuristic).")

	# Remove pre-assigned cases if column exists
	if assigned_agent_col:
		before = len(df)
		df = df[df[assigned_agent_col].isna() | (df[assigned_agent_col].astype(str).str.strip() == "")]
		_log(log_path, f"Filter: Removed pre-assigned cases: {before - len(df)}")

	return df


def _load_escalations(escalation_tracker_path: Optional[str], log_path: str) -> List[str]:
	if not escalation_tracker_path or not os.path.isfile(escalation_tracker_path):
		return []
	if pd is None:
		_log(log_path, "WARNING: pandas not installed; skipping escalation tracker filter.")
		return []
	try:
		df = pd.read_excel(escalation_tracker_path, engine="openpyxl")
		df = _normalize_columns(df)
		col = _detect_columns(df, ["Patient Acct No", "Patient Account No", "Acct No"])
		if not col:
			return []
		return sorted({str(x).strip() for x in df[col].dropna().tolist() if str(x).strip()})
	except Exception as exc:
		_log(log_path, f"WARNING: Could not read escalation tracker: {exc}")
		return []


def _apply_escalation_filter(df: "pd.DataFrame", escalated_ids: List[str], log_path: str) -> "pd.DataFrame":
	if not escalated_ids:
		return df
	col = _detect_columns(df, ["Patient Acct No", "Patient Account No", "Acct No"])
	if not col:
		return df
	before = len(df)
	df = df[~df[col].astype(str).str.strip().isin(set(escalated_ids))].copy()
	_log(log_path, f"Filter: Removed escalated accounts: {before - len(df)}")
	return df


def _assign_agents_and_priorities(
	df: "pd.DataFrame",
	num_agents: int,
	fu_reset_per_location: bool,
	max_provider_assign_threshold: Optional[int],
	log_path: str
) -> "pd.DataFrame":
	df = df.copy()
	visit_type_col = _detect_columns(df, ["Visit Type"])
	provider_col = _detect_columns(df, ["Provider Name", "Provider"])
	appt_date_col = _detect_columns(df, ["Appointment Date", "DOS", "Date Of Service"])
	location_col = _detect_columns(df, ["Appointment Location", "Location"])

	if visit_type_col is None:
		raise RuntimeError("Visit Type column not found for allocation.")

	# NP
	np_mask = df[visit_type_col].astype(str).str.contains("new", case=False, na=False)
	fu_mask = df[visit_type_col].astype(str).str.contains("follow", case=False, na=False)
	np_df = df[np_mask].copy()
	fu_df = df[fu_mask & ~np_mask].copy()
	other_df = df[~np_mask & ~fu_mask].copy()

	def _sort_np(d: "pd.DataFrame") -> "pd.DataFrame":
		keys = []
		if provider_col:
			keys.append(provider_col)
		if appt_date_col:
			keys.append(appt_date_col)
		if location_col:
			keys.append(location_col)
		if keys:
			return d.sort_values(keys, kind="mergesort")
		return d

	def _sort_fu(d: "pd.DataFrame") -> "pd.DataFrame":
		keys = []
		if provider_col:
			keys.append(provider_col)
		if appt_date_col:
			keys.append(appt_date_col)
		if keys:
			return d.sort_values(keys, kind="mergesort")
		return d

	np_df = _sort_np(np_df)
	# Assign NP sequences
	if not np_df.empty:
		np_df = np_df.reset_index(drop=True)
		np_df["Allocation Priority"] = [f"NP-{i+1:03d}" for i in range(len(np_df))]
		np_df["AgentBucket"] = [((i) % num_agents) + 1 for i in range(len(np_df))]

	# FU per-location allocation
	if not fu_df.empty:
		if location_col:
			all_loc = sorted(fu_df[location_col].astype(str).fillna("").unique().tolist())
			parts = []
			for loc in all_loc:
				sub = fu_df[fu_df[location_col].astype(str) == str(loc)].copy()
				sub = _sort_fu(sub).reset_index(drop=True)
				if fu_reset_per_location:
					seq_base = 0
				else:
					seq_base = len(pd.concat(parts)) if parts else 0
				sub["Allocation Priority"] = [f"FU-{seq_base + i + 1:03d}" for i in range(len(sub))]
				sub["AgentBucket"] = [(((seq_base + i)) % num_agents) + 1 for i in range(len(sub))]
				parts.append(sub)
			fu_df = pd.concat(parts, ignore_index=True) if parts else fu_df
		else:
			fu_df = _sort_fu(fu_df).reset_index(drop=True)
			fu_df["Allocation Priority"] = [f"FU-{i+1:03d}" for i in range(len(fu_df))]
			fu_df["AgentBucket"] = [((i) % num_agents) + 1 for i in range(len(fu_df))]

	# Provider grouping preference (simple heuristic)
	# Try to keep all rows for a provider within a segment assigned to same agent by shifting buckets minimally.
	if provider_col and not df.empty:
		for segment_df in (np_df, fu_df):
			if segment_df is None or segment_df.empty:
				continue
			grouped = segment_df.groupby(provider_col)
			new_buckets = segment_df["AgentBucket"].tolist()
			for provider, idxs in ((p, grp.index.tolist()) for p, grp in grouped):
				if not idxs:
					continue
				# Choose the most frequent bucket within current allocation for this provider
				current = [new_buckets[i] for i in idxs]
				if not current:
					continue
				# If too many for threshold, skip regrouping to avoid imbalance
				if max_provider_assign_threshold and len(current) > max_provider_assign_threshold:
					continue
				freq = {}
				for b in current:
					freq[b] = freq.get(b, 0) + 1
				best_bucket = sorted(freq.items(), key=lambda x: (-x[1], x[0]))[0][0]
				for i in idxs:
					new_buckets[i] = best_bucket
			segment_df["AgentBucket"] = new_buckets

	# Merge back and final ordering by AgentBucket then original seq order
	result = pd.concat([np_df, fu_df, other_df], ignore_index=True)
	if "AgentBucket" in result.columns:
		result["_seq_order_tmp"] = result["Allocation Priority"].fillna("").astype(str)
		result = result.sort_values(["AgentBucket", "_seq_order_tmp"], kind="mergesort").drop(columns=["_seq_order_tmp"], errors="ignore")
	return result


def _write_outputs(
	df: "pd.DataFrame",
	outputs_dir: str,
	log_path: str
) -> Tuple[str, str]:
	ts = _now_ts()
	os.makedirs(outputs_dir, exist_ok=True)
	import_fp = os.path.join(outputs_dir, "latest_import.csv")
	allocation_fp = os.path.join(outputs_dir, f"allocation_report_{ts}.csv")
	df.to_csv(import_fp, index=False)
	df[["Allocation Priority", "AgentBucket"]].assign(
		AssignedAgent=lambda d: d["AgentBucket"].apply(lambda x: f"Agent {int(x)}")
	).to_csv(allocation_fp, index=False)
	_log(log_path, f"Wrote import: {import_fp}")
	_log(log_path, f"Wrote allocation report: {allocation_fp}")
	return import_fp, allocation_fp


def run(
	input_csv: str,
	workbook_path: Optional[str],
	config_path: Optional[str]
) -> int:
	base_cfg = {
		"paths": {
			"uploads_dir": os.path.join(os.getcwd(), "inputs", "uploads"),
			"outputs_dir": os.path.join(os.getcwd(), "outputs"),
			"logs_dir": os.path.join(os.getcwd(), "logs"),
			"escalation_tracker": None,
			"workbook": workbook_path
		},
		"num_agents": 8,
		"max_provider_assign_threshold": 40,
		"fu_reset_per_location": True,
		"healthx": {
			"method": "api",
			"api_endpoint": None,
			"api_key": None
		}
	}
	user_cfg = _load_yaml(config_path)
	# Merge configs (shallow)
	cfg = base_cfg
	for k, v in (user_cfg or {}).items():
		if isinstance(v, dict) and isinstance(cfg.get(k), dict):
			cfg[k].update(v)
		else:
			cfg[k] = v

	paths = cfg.get("paths", {})
	paths = {
		"uploads_dir": paths.get("uploads_dir") or base_cfg["paths"]["uploads_dir"],
		"outputs_dir": paths.get("outputs_dir") or base_cfg["paths"]["outputs_dir"],
		"logs_dir": paths.get("logs_dir") or base_cfg["paths"]["logs_dir"],
		"escalation_tracker": paths.get("escalation_tracker"),
		"workbook": paths.get("workbook") or workbook_path
	}
	_ensure_dirs(paths)
	log_path = _init_logging(paths["logs_dir"])

	try:
		_log(log_path, f"Config: num_agents={cfg.get('num_agents')}, fu_reset_per_location={cfg.get('fu_reset_per_location')}, threshold={cfg.get('max_provider_assign_threshold')}")
		_log(log_path, f"Input CSV: {input_csv}")
		if not os.path.isfile(input_csv):
			_log(log_path, "ERROR: Input CSV does not exist.")
			return 2

		# 1) Try macro path if workbook provided
		if paths.get("workbook") and os.path.isfile(paths["workbook"]):
			ok = _try_run_macro_and_paste_csv(paths["workbook"], input_csv, log_path)
		else:
			ok = False
			if not paths.get("workbook"):
				_log(log_path, "INFO: No workbook provided; will use pandas-only path.")
			else:
				_log(log_path, "WARNING: Workbook path invalid; using pandas-only path.")

		# 2) Read cleaned data (Raw + Help) if workbook available, else read CSV and try Help only
		help_df, raw_df = (None, None)
		if paths.get("workbook") and os.path.isfile(paths["workbook"]):
			help_df, raw_df = _read_excel_help(paths["workbook"], log_path)
		if raw_df is None:
			if pd is None:
				_log(log_path, "ERROR: pandas not installed; cannot proceed.")
				return 3
			_log(log_path, "Reading input CSV directly (no Raw sheet available).")
			raw_df = pd.read_csv(input_csv, dtype=str, keep_default_na=False)

		_log(log_path, f"Rows before filters: {len(raw_df)}")

		# 3) Dual validation + base filters
		df = _dual_validation_and_filters(raw_df, help_df, paths["outputs_dir"], log_path)

		# 4) Escalation tracker filter
		escalated_ids = _load_escalations(paths.get("escalation_tracker"), log_path)
		df = _apply_escalation_filter(df, escalated_ids, log_path)

		# 5) Allocation
		df_alloc = _assign_agents_and_priorities(
			df=df,
			num_agents=int(cfg.get("num_agents", 8)),
			fu_reset_per_location=bool(cfg.get("fu_reset_per_location", True)),
			max_provider_assign_threshold=cfg.get("max_provider_assign_threshold"),
			log_path=log_path
		)
		_log(log_path, f"Rows after allocation: {len(df_alloc)}")

		# 6) Outputs
		_write_outputs(df_alloc, paths["outputs_dir"], log_path)
		_log(log_path, "Run complete.")
		return 0
	except Exception as exc:
		_log(log_path, f"FATAL: {exc}")
		_log(log_path, traceback.format_exc())
		return 1


def main():
	parser = argparse.ArgumentParser(description="Audentes Verification / EV Inventory Import automation")
	parser.add_argument("--input", required=True, help="Path to the eCW CSV file")
	parser.add_argument("--wb", required=False, help="Path to Audentes_Verification1.xlsm")
	parser.add_argument("--config", required=False, help="Path to bot_config.yml")
	args = parser.parse_args()
	sys.exit(run(args.input, args.wb, args.config))


if __name__ == "__main__":
	main()


