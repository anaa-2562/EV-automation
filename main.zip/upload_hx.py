"""
upload_hx.py - Selenium automation for HealthX portal file upload
Automates login and file upload process to HealthX portal.
"""
import json
import os
import time
from datetime import datetime
import traceback
from typing import Tuple

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
try:
    # Optional .env support for credentials
    from dotenv import load_dotenv
    import sys
    # Load .env from EXE directory (when frozen) or script directory (when running from source)
    env_paths = []
    try:
        # When frozen (EXE), load from EXE directory
        exe_dir = os.path.dirname(os.path.abspath(sys.executable))
        env_paths.append(os.path.join(exe_dir, ".env"))
        env_paths.append(os.path.join(os.path.dirname(exe_dir), ".env"))  # parent of dist/
    except Exception:
        pass
    try:
        # When running from source, load from script directory
        script_dir = os.path.dirname(os.path.abspath(__file__))
        env_paths.append(os.path.join(script_dir, ".env"))
        env_paths.append(os.path.join(os.path.dirname(script_dir), ".env"))
    except Exception:
        pass
    # Also try current working directory
    env_paths.append(os.path.join(os.getcwd(), ".env"))
    
    # Try each path until one works
    loaded = False
    for env_path in env_paths:
        if env_path and os.path.isfile(env_path):
            load_dotenv(env_path, override=True)
            loaded = True
            break
    # Fallback: try default load_dotenv() behavior
    if not loaded:
        load_dotenv()
except Exception:
    pass


def _ensure_logs_dir() -> str:
    """Ensure logs directory exists."""
    logs_dir = os.path.join(os.getcwd(), "logs")
    os.makedirs(logs_dir, exist_ok=True)
    return logs_dir


def _log(message: str, log_path: str = None) -> None:
    """Write message to log file with timestamp (consistent with process_data.py)."""
    if log_path is None:
        logs_dir = _ensure_logs_dir()
        # Use timestamp-based log file (same format as process_data)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = os.path.join(logs_dir, f"run_{ts}.txt")
    
    # Append to existing log if created in same second, otherwise create new
    with open(log_path, "a", encoding="utf-8") as f:
        log_ts = datetime.now().strftime("%H:%M:%S")
        f.write(f"[{log_ts}] {message}\n")


def _load_config():
    """Load configuration from config.json with robust path resolution.
    Searches current working dir, executable dir, script dir, and their parents.
    """
    candidates = []
    # 1) Current working directory
    candidates.append(os.path.join(os.getcwd(), "config.json"))
    # 2) Executable directory (when frozen)
    try:
        exe_dir = os.path.dirname(os.path.abspath(getattr(__import__('sys'), 'executable')))
        candidates.append(os.path.join(exe_dir, "config.json"))
        candidates.append(os.path.join(os.path.dirname(exe_dir), "config.json"))  # parent of dist/
    except Exception:
        pass
    # 3) Script directory (when running from source)
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        candidates.append(os.path.join(script_dir, "config.json"))
        candidates.append(os.path.join(os.path.dirname(script_dir), "config.json"))
    except Exception:
        pass

    for path in candidates:
        if path and os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)

    raise FileNotFoundError(f"config.json not found in: {candidates}")


def _resolve_secret(value: str) -> str:
    """
    Resolve secret value from environment variable if it starts with ENV_.
    Otherwise return the value as-is.
    """
    if isinstance(value, str) and value.upper().startswith("ENV_"):
        env_key = value
        return os.getenv(env_key, "")
    return value


def upload_to_healthx(file_path: str, log_path: str = None) -> Tuple[bool, str]:
    """
    Upload processed Excel file to HealthX portal using Selenium automation.
    
    Args:
        file_path: Path to the Excel file to upload
        
    Returns:
        Tuple of (success: bool, message: str)
    """
    _log(f"Starting HealthX upload process for: {os.path.basename(file_path)}", log_path=log_path)
    
    cfg = _load_config()
    url = cfg.get("healthx_url", "").strip()
    # Support either user_id or username (prefer user_id)
    user_cfg_value = cfg.get("user_id") or cfg.get("username", "")
    username = _resolve_secret(user_cfg_value)
    password = _resolve_secret(cfg.get("password", ""))
    headless_mode = cfg.get("headless_mode", False)
    visual_mode = cfg.get("visual_mode", False)  # if True, keep images/animations for operator to observe
    client_text = cfg.get("hx_client_text", "Audentes").strip()

    if not url:
        error_msg = "HealthX URL missing in config.json"
        _log(f"ERROR: {error_msg}", log_path=log_path)
        return False, error_msg
        
    if not username or not password:
        error_msg = "Credentials missing (check config.json or environment variables)"
        _log(f"ERROR: {error_msg}", log_path=log_path)
        return False, error_msg
        
    if not os.path.isfile(file_path):
        error_msg = f"Output file not found: {file_path}"
        _log(f"ERROR: {error_msg}", log_path=log_path)
        return False, error_msg

    # Configure Chrome options
    opts = Options()
    if headless_mode:
        opts.add_argument("--headless")
        opts.add_argument("--disable-gpu")
    opts.add_argument("--start-maximized")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    opts.add_experimental_option('useAutomationExtension', False)
    # Speed/robustness tweaks (keep things visual if requested)
    if not visual_mode:
        try:
            # Faster DOM readiness; don't wait for all resources
            opts.page_load_strategy = "eager"
        except Exception:
            pass
        opts.add_argument("--disable-extensions")
        opts.add_argument("--disable-infobars")
        opts.add_argument("--disable-notifications")
        opts.add_argument("--disable-animations")
        # Reduce resource usage
        opts.add_argument("--blink-settings=imagesEnabled=false")

    # Retry logic: try up to 2 times
    for attempt in range(2):
        try:
            _log(f"Launching Chrome browser (attempt {attempt + 1}/2)...", log_path=log_path)
            try:
                driver = webdriver.Chrome(options=opts)
            except Exception as drv_exc:
                _log(f"ERROR: Failed to start Chrome: {drv_exc}", log_path=log_path)
                _log(traceback.format_exc(), log_path=log_path)
                raise
            try:
                # Tighter, still safe default waits
                driver.set_page_load_timeout(20)
                wait = WebDriverWait(driver, 15)
                def snap(name: str):
                    try:
                        logs_dir = _ensure_logs_dir()
                        fp = os.path.join(logs_dir, f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{name}.png")
                        driver.save_screenshot(fp)
                        _log(f"Saved screenshot: {fp}", log_path=log_path)
                    except Exception:
                        pass
                
                # Navigate to login page
                _log(f"Navigating to HealthX login page: {url}", log_path=log_path)
                driver.get(url)
                # Wait for username or fallback quickly
                for locator in [
                    (By.NAME, "username"),
                    (By.ID, "username"),
                    (By.XPATH, "//input[@type='text' or @type='email']"),
                ]:
                    try:
                        wait.until(EC.presence_of_element_located(locator))
                        break
                    except Exception:
                        continue

                # Find and fill login (prefers single-page email+password per screenshot)
                _log("Locating email and password fields...", log_path=log_path)
                def _find_email():
                    for selector in [
                        (By.XPATH, "//input[@placeholder='Enter your email address']"),
                        (By.CSS_SELECTOR, "input[type='email']"),
                        (By.NAME, "email"),
                        (By.ID, "email"),
                        (By.NAME, "username"),
                        (By.ID, "username"),
                    ]:
                        try:
                            return wait.until(EC.element_to_be_clickable(selector))
                        except Exception:
                            continue
                    return None
                def _find_password_simple():
                    for sel in [
                        (By.XPATH, "//input[@placeholder='Enter password']"),
                        (By.CSS_SELECTOR, "input[type='password']"),
                        (By.NAME, "password"),
                        (By.ID, "password"),
                    ]:
                        try:
                            return wait.until(EC.element_to_be_clickable(sel))
                        except Exception:
                            continue
                    return None

                email_input = _find_email()
                if not email_input:
                    raise Exception("Could not find email/username input field")
                pass_input = _find_password_simple()
                # Type credentials
                email_input.clear(); email_input.send_keys(username)
                if pass_input:
                    pass_input.clear(); pass_input.send_keys(password)
                if visual_mode:
                    snap("login_filled")

                # If password not present, fall back to 2-step discovery
                def _find_password(max_wait_seconds: int = 20):
                    end_time = time.time() + max_wait_seconds
                    while time.time() < end_time:
                        # Search in current context
                        for sel in [
                            (By.NAME, "password"),
                            (By.ID, "password"),
                            (By.CSS_SELECTOR, "input[type='password']"),
                            (By.XPATH, "//input[@placeholder='Enter your password']"),
                            (By.XPATH, "//input[@placeholder='Enter password']"),
                        ]:
                            try:
                                return WebDriverWait(driver, 2).until(EC.element_to_be_clickable(sel))
                            except Exception:
                                continue
                        # Search within iframes
                        try:
                            driver.switch_to.default_content()
                            frames = driver.find_elements(By.TAG_NAME, "iframe")
                            for fr in frames:
                                try:
                                    driver.switch_to.frame(fr)
                                    for sel in [
                                        (By.NAME, "password"),
                                        (By.ID, "password"),
                                        (By.CSS_SELECTOR, "input[type='password']"),
                                    ]:
                                        try:
                                            el = WebDriverWait(driver, 1.5).until(EC.element_to_be_clickable(sel))
                                            _log("Found password field inside iframe", log_path=log_path)
                                            return el
                                        except Exception:
                                            continue
                                finally:
                                    driver.switch_to.default_content()
                        except Exception:
                            driver.switch_to.default_content()
                        time.sleep(0.5)
                    return None

                if pass_input is None:
                    pass_input = _find_password(max_wait_seconds=5)
                if pass_input is None:
                    _log("Password field not visible; attempting Next/Continue/Enter...", log_path=log_path)
                    # Try Enter on email field first
                    try:
                        from selenium.webdriver.common.keys import Keys
                        email_input.send_keys(Keys.ENTER)
                        pass_input = _find_password(max_wait_seconds=8)
                    except Exception:
                        pass
                if pass_input is None:
                    next_btn = None
                    for bsel in [
                        (By.XPATH, "//button[contains(., 'Next') or contains(., 'Continue')]"),
                        (By.CSS_SELECTOR, "button[type='submit']"),
                    ]:
                        try:
                            next_btn = wait.until(EC.element_to_be_clickable(bsel)); break
                        except Exception:
                            continue
                    if next_btn:
                        next_btn.click()
                        pass_input = _find_password(max_wait_seconds=10)
                if pass_input is None:
                    raise Exception("Could not find password input field after email step")

                if pass_input:
                    _log("Entering password and submitting...", log_path=log_path)
                    pass_input.clear(); pass_input.send_keys(password)

                # Click Sign in/Login
                login_btn = None
                for selector in [
                    (By.XPATH, "//button[contains(., 'Sign in') or contains(., 'Login')]"),
                    (By.CSS_SELECTOR, "button[type='submit']"),
                    (By.CSS_SELECTOR, "input[type='submit']"),
                ]:
                    try:
                        login_btn = wait.until(EC.element_to_be_clickable(selector)); break
                    except Exception:
                        continue
                if login_btn:
                    login_btn.click()
                else:
                    # Fallback: press Enter on password field
                    from selenium.webdriver.common.keys import Keys
                    pass_input.send_keys(Keys.ENTER)
                if visual_mode:
                    snap("after_login_submit")
                # Wait for potential post-login element (menu)
                for post_login in [
                    (By.XPATH, "//a[contains(., 'Eligibility')]"),
                    (By.CSS_SELECTOR, "a[href*='Import'], a[href*='import']"),
                ]:
                    try:
                        WebDriverWait(driver, 20).until(EC.presence_of_element_located(post_login))
                        break
                    except Exception:
                        continue

                # Navigate to Import/Upload page under Eligibility Verification
                _log("Navigating to upload/import page...", log_path=log_path)
                try:
                    menu = wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(., 'Eligibility Verification') or contains(., 'Eligibility')]")))
                    menu.click(); time.sleep(1)
                except Exception:
                    pass
                import_link = None
                for selector in [
                    (By.LINK_TEXT, "Import"),
                    (By.PARTIAL_LINK_TEXT, "Import"),
                    (By.PARTIAL_LINK_TEXT, "Upload"),
                    (By.XPATH, "//a[contains(., 'Import') or contains(., 'Upload')]") ,
                    (By.CSS_SELECTOR, "a[href*='Import'], a[href*='import'], a[href*='upload']"),
                ]:
                    try:
                        import_link = wait.until(EC.element_to_be_clickable(selector))
                        if import_link:
                            break
                    except:
                        continue

                if not import_link:
                    raise Exception("Could not find Import/Upload link")

                import_link.click()
                if visual_mode:
                    snap("import_page_opened")
                # Allow navigation with a focused wait; switch into iframe if needed
                # Handle transient server 500 on import page
                def _recover_if_http_500(max_retries: int = 3) -> None:
                    for _ in range(max_retries):
                        try:
                            body_text = (driver.page_source or "").lower()
                        except Exception:
                            body_text = ""
                        if "http error 500" in body_text or "isn't working" in body_text or "unable to handle this request" in body_text:
                            _log("Detected HTTP 500 on import page; refreshing and retrying...", log_path=log_path)
                            try:
                                driver.refresh(); time.sleep(2)
                            except Exception:
                                pass
                            continue
                        break
                _recover_if_http_500()
                def _switch_to_upload_iframe():
                    try:
                        # Fast path: element on main page
                        for loc in [
                            (By.CSS_SELECTOR, "input[type='file']"),
                            (By.ID, "formFileSm"),
                        ]:
                            try:
                                WebDriverWait(driver, 6).until(EC.presence_of_element_located(loc))
                                return True
                            except Exception:
                                continue
                        # Try iframes
                        frames = driver.find_elements(By.TAG_NAME, "iframe")
                        for i, fr in enumerate(frames):
                            driver.switch_to.default_content()
                            driver.switch_to.frame(fr)
                            for loc in [
                                (By.CSS_SELECTOR, "input[type='file']"),
                                (By.ID, "formFileSm"),
                            ]:
                                try:
                                    WebDriverWait(driver, 4).until(EC.presence_of_element_located(loc))
                                    _log(f"Switched to iframe #{i} containing upload form", log_path=log_path)
                                    return True
                                except Exception:
                                    continue
                        driver.switch_to.default_content()
                    except Exception:
                        driver.switch_to.default_content()
                    return False
                _switch_to_upload_iframe()

                # If a client selection is required, select the configured client
                _log("Selecting client...", log_path=log_path)
                try:
                    # Prefer the visible dropdown right after the 'Client' label
                    dropdown = None
                    for bsel in [
                        (By.XPATH, "//label[contains(normalize-space(.), 'Client')]/following::*[self::select or @role='combobox' or contains(@class,'select') or contains(@class,'dropdown') or self::div][1]"),
                        (By.CSS_SELECTOR, "select[name*='client']"),
                    ]:
                        try:
                            dropdown = wait.until(EC.element_to_be_clickable(bsel)); break
                        except Exception:
                            continue
                    if not dropdown:
                        _log("Client dropdown not found; skipping client selection", log_path=log_path)
                    else:
                        # Helper: find options container and click desired item
                        def _click_option(desired_text: str) -> bool:
                            container = None
                            # Try common list containers
                            for cont_sel in [
                                (By.XPATH, "//ul[contains(@class,'menu') or contains(@class,'list') or contains(@class,'options')]"),
                                (By.XPATH, "//div[contains(@class,'menu') or contains(@class,'listbox') or contains(@class,'options')]"),
                                (By.XPATH, "//div[@role='listbox'] | //ul[@role='listbox']"),
                            ]:
                                try:
                                    container = WebDriverWait(driver, 5).until(EC.presence_of_element_located(cont_sel)); break
                                except Exception:
                                    continue
                            # Search for exact text then partial text inside any container
                            for opt_sel in [
                                (By.XPATH, f"//*[normalize-space(.)='{desired_text}']"),
                                (By.XPATH, f".//*[normalize-space(.)='{desired_text}']"),
                                (By.XPATH, f"//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{desired_text.lower()}')]"),
                            ]:
                                try:
                                    el = WebDriverWait(driver, 5).until(EC.element_to_be_clickable(opt_sel))
                                    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", el)
                                    el.click(); time.sleep(0.2)
                                    return True
                                except Exception:
                                    continue
                            return False

                        # If it's a native select, use Select API
                        tag = (dropdown.tag_name or "").lower()
                        if tag == "select":
                            from selenium.webdriver.support.ui import Select
                            try:
                                sel = Select(dropdown)
                                # Try exact first, then partial
                                try:
                                    sel.select_by_visible_text(client_text)
                                except Exception:
                                    for opt in sel.options:
                                        if client_text.lower() in (opt.text or "").lower():
                                            opt.click(); break
                                _log(f"Client selected via <select>: {client_text}", log_path=log_path)
                            except Exception as exc:
                                _log(f"Select API failed: {exc}", log_path=log_path)
                        else:
                            # Custom dropdown: click to open
                            dropdown.click(); time.sleep(0.3)
                            if _click_option(client_text):
                                _log(f"Client selected via custom dropdown: {client_text}", log_path=log_path)
                            else:
                                _log(f"Client option not found by visible/partial text: {client_text}. Retrying with keyword 'Audentes - Audentes Verification'", log_path=log_path)
                                # Hard-code exact label as per operator instruction
                                hard_label = "Audentes - Audentes Verification"
                                # Re-open if necessary
                                try:
                                    dropdown.click(); time.sleep(0.2)
                                except Exception:
                                    pass
                                _click_option(hard_label)
                        # Verify the selection text updated; if still default, retry via partial keyword
                        selected_text = ""
                        try:
                            selected_text = dropdown.text or dropdown.get_attribute("value") or ""
                        except Exception:
                            selected_text = ""
                        if ("select" in (selected_text or "").lower()) or (client_text.lower() not in (selected_text or "").lower()):
                            _log("Client still not committed; retrying with partial keyword 'Audentes'...", log_path=log_path)
                            # Retry with a safer short keyword
                            short_key = "Audentes"
                            try:
                                dropdown.click(); time.sleep(0.2)
                                alt = wait.until(EC.element_to_be_clickable((By.XPATH, f"//li[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{short_key.lower()}')] | //div[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'), '{short_key.lower()}')]")))
                                alt.click(); time.sleep(0.2)
                            except Exception:
                                pass
                        if visual_mode:
                            snap("client_selected")
                except Exception as sel_exc:
                    _log(f"Client selection step skipped/failed: {sel_exc}", log_path=log_path)
                    _log(traceback.format_exc(), log_path=log_path)

                # Find file upload input
                _log("Looking for file upload input...", log_path=log_path)
                upload_input = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "input[type='file'], #formFileSm[type='file']")))

                # If the input is hidden, force-make it interactable
                if not upload_input.is_displayed() or not upload_input.is_enabled():
                    _log("File input not interactable; attempting to unhide via JS...", log_path=log_path)
                    try:
                        driver.execute_script("""
                            arguments[0].style.display='block';
                            arguments[0].style.visibility='visible';
                            arguments[0].removeAttribute('hidden');
                            arguments[0].classList.remove('d-none');
                        """, upload_input)
                    except Exception:
                        pass
                    # If still not displayed, try clicking Browse label/button to reveal
                    if not upload_input.is_displayed():
                        _log("Trying Browse/Choose file control to reveal input...", log_path=log_path)
                        for browse_sel in [
                            (By.XPATH, "//button[contains(., 'Browse') or contains(., 'Choose file')]"),
                            (By.XPATH, "//label[contains(., 'Browse') or contains(., 'Choose file')]")
                        ]:
                            try:
                                b = wait.until(EC.element_to_be_clickable(browse_sel))
                                b.click(); time.sleep(0.5)
                                break
                            except Exception:
                                continue
                        upload_input = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "input[type='file'], #formFileSm[type='file']")))

                # Upload file via send_keys (this bypasses the native file picker dialog)
                abs_file_path = os.path.abspath(file_path)
                _log(f"Uploading file: {abs_file_path}", log_path=log_path)
                driver.execute_script("arguments[0].scrollIntoView({block:'center'});", upload_input)
                try:
                    upload_input.send_keys(abs_file_path)
                except Exception as up_exc:
                    _log(f"Standard send_keys failed on file input: {up_exc}; retrying after JS focus...", log_path=log_path)
                    driver.execute_script("arguments[0].focus();", upload_input)
                    upload_input.send_keys(abs_file_path)
                time.sleep(2)

                # Find and click submit/import button
                submit_btn = None
                for selector in [
                    (By.ID, "btnSubmit"),
                    (By.CSS_SELECTOR, "button[type='submit']"),
                    (By.XPATH, "//button[contains(text(), 'Import') or contains(text(), 'Submit') or contains(text(), 'Upload')]"),
                    (By.CSS_SELECTOR, "input[type='submit']"),
                ]:
                    try:
                        submit_btn = wait.until(EC.presence_of_element_located(selector))
                        if submit_btn:
                            break
                    except:
                        continue

                if not submit_btn:
                    raise Exception("Could not find submit/upload button")

                _log("Clicking submit button...", log_path=log_path)
                try:
                    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", submit_btn)
                    if submit_btn.get_attribute("disabled"):
                        _log("Submit button appears disabled; waiting briefly for enable...", log_path=log_path)
                        time.sleep(1.0)
                    submit_btn.click()
                except Exception:
                    _log("Regular click failed; attempting JS click for submit...", log_path=log_path)
                    driver.execute_script("arguments[0].click();", submit_btn)

                # Wait for success confirmation
                _log("Waiting for upload confirmation...", log_path=log_path)
                time.sleep(5)  # Wait for upload to process
                if visual_mode:
                    snap("after_upload_click")

                # Check for success indicators
                success_indicators = [
                    "//*[contains(text(), 'Import Successful')]",
                    "//*[contains(text(), 'Success')]",
                    "//*[contains(text(), 'completed')]",
                    "//*[contains(text(), 'Complete')]",
                    "//*[contains(text(), 'Uploaded')]",
                ]

                success_found = False
                for indicator in success_indicators:
                    try:
                        element = driver.find_element(By.XPATH, indicator)
                        if element:
                            success_found = True
                            break
                    except:
                        continue

                if not success_found:
                    # If no explicit success message, assume success if we got this far
                    # (portal may not show explicit message)
                    _log("No explicit success message found, but upload appears complete", log_path=log_path)

                _log(f"HealthX upload completed successfully: {os.path.basename(file_path)}", log_path=log_path)
                if visual_mode:
                    snap("import_success")

                # Navigate to EV Allocation and initiate process
                try:
                    _log("Navigating to EV Allocation to initiate process...", log_path=log_path)
                    try:
                        menu = wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(., 'Eligibility Verification') or contains(., 'Eligibility')]")))
                        menu.click(); time.sleep(1)
                    except Exception:
                        pass
                    if visual_mode:
                        snap("before_ev_allocation")
                    for sel in [
                        (By.LINK_TEXT, "EV Allocation"),
                        (By.PARTIAL_LINK_TEXT, "Allocation"),
                        (By.XPATH, "//a[contains(., 'EV Allocation') or contains(., 'Allocation')]")
                    ]:
                        try:
                            el = wait.until(EC.element_to_be_clickable(sel))
                            el.click(); time.sleep(2); break
                        except Exception:
                            continue
                    if visual_mode:
                        snap("ev_allocation_page")
                    for btn_sel in [
                        (By.XPATH, "//button[contains(., 'Initiate EV Process') or contains(., 'Initiate') or contains(., 'EV Process')]") ,
                        (By.CSS_SELECTOR, "button#btnInitiateEV, button[name*='Initiate']"),
                    ]:
                        try:
                            ev_btn = wait.until(EC.element_to_be_clickable(btn_sel))
                            ev_btn.click(); time.sleep(2); break
                        except Exception:
                            continue
                    _log("Initiated EV process.", log_path=log_path)
                    if visual_mode:
                        snap("ev_initiated")
                except Exception as ev_exc:
                    _log(f"EV Allocation step not found/failed: {ev_exc}", log_path=log_path)

                return True, "Upload successful (EV initiated if available)"
            finally:
                try:
                    driver.quit()
                except Exception:
                    pass

        except Exception as exc:
            error_msg = f"Upload attempt {attempt + 1} failed: {str(exc)}"
            _log(f"ERROR: {error_msg}", log_path=log_path)
            if attempt == 0:
                _log("Retrying upload...", log_path=log_path)
                time.sleep(3)
                continue
            return False, f"Upload failed: {str(exc)}"

    return False, "Upload failed after all retry attempts"


def hx_upload(file_path: str, log_path: str = None) -> Tuple[bool, str]:
    """
    Upload processed Excel file to HealthX portal using Selenium automation.
    Uses the working approach with specific XPath selectors.
    
    Args:
        file_path: Path to the Excel file to upload
        log_path: Optional path to log file
        
    Returns:
        Tuple of (success: bool, message: str)
    """
    _log(f"Starting HealthX upload process for: {os.path.basename(file_path)}", log_path=log_path)
    
    # Load configuration
    try:
        cfg = _load_config()
        HX_website = cfg.get("healthx_url", "").strip()
        user_cfg_value = cfg.get("user_id") or cfg.get("username", "")
        username = _resolve_secret(user_cfg_value)
        password = _resolve_secret(cfg.get("password", ""))
    except Exception as e:
        error_msg = f"Failed to load config: {str(e)}"
        _log(f"ERROR: {error_msg}", log_path=log_path)
        return False, error_msg
    
    if not HX_website:
        error_msg = "HealthX URL missing in config.json"
        _log(f"ERROR: {error_msg}", log_path=log_path)
        return False, error_msg
        
    if not username or not password:
        error_msg = "Credentials missing (check config.json or environment variables)"
        _log(f"ERROR: {error_msg}", log_path=log_path)
        return False, error_msg
        
    if not os.path.isfile(file_path):
        error_msg = f"Output file not found: {file_path}"
        _log(f"ERROR: {error_msg}", log_path=log_path)
        return False, error_msg

    driver = None
    try:
        _log("Configuring Chrome browser...", log_path=log_path)
        chrome_options = webdriver.ChromeOptions()
        # Use a valid download directory (current working directory)
        Download_dir = os.getcwd()
 
        chrome_options.add_argument('--log-level=3')
        chrome_options.add_argument('--start-maximized')
        prefs = {
            "plugins.plugin_list": [{"enabled": False, "name": "Chrome PDF Viewer"}],
            "profile.default_content_settings_values_notifications": 2,
            "download.default_directory": Download_dir,
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "download.extension_to_open": "",
            "plugin.always_open_pdf_externally": True,
        }
        chrome_options.add_experimental_option('prefs', prefs)
        
        _log("Installing ChromeDriver and launching browser...", log_path=log_path)
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=chrome_options)
        wait = WebDriverWait(driver, 45)
 
        _log(f"Navigating to HealthX website: {HX_website}", log_path=log_path)
        driver.get(HX_website)
        driver.maximize_window()
        time.sleep(2)
 
        _log("Entering login credentials...", log_path=log_path)
        username_input = wait.until(EC.presence_of_element_located((By.XPATH, '//input[@id="email"]')))
        username_input.send_keys(username)
        
        password_input = wait.until(EC.presence_of_element_located((By.XPATH, '//input[@id="password"]')))
        password_input.send_keys(password)
        
        login_btn = wait.until(EC.presence_of_element_located((By.XPATH, '//input[@value="Sign in"]')))
        login_btn.click()
        time.sleep(5)
        
        _log("Navigating to Eligibility Verification menu...", log_path=log_path)
        menu_item = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="sidebar-toggle"]/li[5]/a')))
        menu_item.click()
        time.sleep(5)
        
        _log("Clicking on Import option...", log_path=log_path)
        import_menu = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="EVSummary"]/li[1]/a')))
        import_menu.click()
        time.sleep(5)
        
        _log("Selecting campaign: Audentes - Audentes Verification...", log_path=log_path)
        campaign_dropdown = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="select2-campaign-container"]')))
        campaign_dropdown.click()
        time.sleep(5)
        
        campaign_option = wait.until(EC.presence_of_element_located((By.XPATH, "//li[contains(text(), 'Audentes - Audentes Verification') and contains(@class, 'select2-results__option')]")))
        campaign_option.click()
        time.sleep(2)
 
        _log("Preparing file upload...", log_path=log_path)
        import_button = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="ImportButtonRed"]')))
        time.sleep(5)
        
        file_input = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="customFile"]')))
        time.sleep(5)
        
        # Use absolute path for file upload
        abs_file_path = os.path.abspath(file_path)
        _log(f"Uploading file: {abs_file_path}", log_path=log_path)
        file_input.send_keys(abs_file_path)
        time.sleep(10)
        
        _log("Clicking import button...", log_path=log_path)
        import_button.click()
        
        _log("Waiting for upload confirmation...", log_path=log_path)
        # Wait for success message
        max_wait_time = 120  # Maximum 2 minutes wait
        start_time = time.time()
        success_found = False
        while time.time() - start_time < max_wait_time:
            time.sleep(2)
            try:
                wait.until(EC.presence_of_element_located((By.XPATH, '//p[contains(@class, "message") and contains(text(), "uploaded Successfully")]')))
                success_found = True
                _log("Upload success message detected!", log_path=log_path)
                break
            except:
                pass
        
        if not success_found:
            _log("Warning: Upload success message not detected within timeout, but continuing...", log_path=log_path)
        
        _log("Navigating to EV Allocation...", log_path=log_path)
        ev_allocation = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="EVSummary"]/li[2]/a')))
        ev_allocation.click()
        time.sleep(10)
        
        _log("Selecting client filter: Tricity - Verification...", log_path=log_path)
        client_filter = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="select2-client_filter-container"]')))
        client_filter.click()
        time.sleep(2)
        
        client_option = wait.until(EC.presence_of_element_located((By.XPATH, "//li[contains(text(), 'Tricity - Verification')]")))
        client_option.click()
        time.sleep(5)
        
        _log("Scrolling to bottom and initiating EV process...", log_path=log_path)
        time.sleep(10)
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(5)
        
        initiate_element = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="newrecord_evprocess"]/div/a')))
        initiate_element.click()
        time.sleep(5)
        
        try:
            confirm_button = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@id="InitiateConfirmAction"]')))
            confirm_button.click()
            _log("EV process initiated successfully!", log_path=log_path)
        except Exception as e:
            _log(f"Warning: Could not click confirm button: {str(e)}", log_path=log_path)
        
        time.sleep(5)
        
        _log(f"HealthX upload completed successfully: {os.path.basename(file_path)}", log_path=log_path)
        return True, "Upload successful and EV process initiated"
        
    except Exception as exc:
        error_msg = f"Upload failed: {str(exc)}"
        _log(f"ERROR: {error_msg}", log_path=log_path)
        _log(traceback.format_exc(), log_path=log_path)
        return False, error_msg
        
    finally:
        if driver:
            try:
                driver.quit()
                _log("Browser closed.", log_path=log_path)
            except Exception:
                pass
