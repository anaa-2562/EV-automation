"""Temporary script to check macro logic for Appointment State derivation"""
import pandas as pd

# Check output file columns
print("=" * 60)
print("CHECKING OUTPUT FILE COLUMNS")
print("=" * 60)
df_out = pd.read_excel('dist/outputs/HealthX_Import_20251105_110228.xlsx', engine='openpyxl')
print(f"\nColumns in processed output ({len(df_out.columns)} total):")
for i, col in enumerate(df_out.columns):
    print(f"  {i+1:2d}. '{col}'")
    
if ' Appointment State' in df_out.columns:
    print(f"\nSample ' Appointment State' values:")
    print(df_out[' Appointment State'].head(10).tolist())
elif 'Appointment State' in df_out.columns:
    print(f"\nSample 'Appointment State' values:")
    print(df_out['Appointment State'].head(10).tolist())
else:
    print("\n❌ NO Appointment State column found in output!")

# Check Help sheet structure
print("\n" + "=" * 60)
print("CHECKING HELP SHEET STRUCTURE")
print("=" * 60)
help_df = pd.read_excel('Audentes_Verification1.xlsm', sheet_name='Help', engine='openpyxl')
print(f"\nHelp sheet columns: {list(help_df.columns)}")
print(f"\nHelp sheet shape: {help_df.shape}")
print(f"\nFirst 10 rows of Help sheet:")
print(help_df.head(10).to_string())

# Check if there's a lookup pattern: Provider Name -> Appointment State
print("\n" + "=" * 60)
print("CHECKING LOOKUP PATTERN")
print("=" * 60)
if 'Appointment Provider Name' in help_df.columns and ' Appointment State' in help_df.columns:
    print("\nProvider -> State mapping examples:")
    mapping = help_df[['Appointment Provider Name', ' Appointment State']].drop_duplicates()
    print(mapping.head(15).to_string())
    
    print(f"\nUnique providers: {help_df['Appointment Provider Name'].nunique()}")
    print(f"Unique states: {help_df[' Appointment State'].nunique()}")
    print(f"\nState values: {sorted(help_df[' Appointment State'].dropna().unique())}")

# Check raw input file
print("\n" + "=" * 60)
print("CHECKING RAW INPUT FILE")
print("=" * 60)
df_raw = pd.read_csv('dist/inputs/eCW_20251105_110228.csv', nrows=5)
print(f"\nRaw input columns (first 40):")
for i, col in enumerate(df_raw.columns[:40]):
    print(f"  {i+1:2d}. '{col}'")
    
if ' Appointment State' in df_raw.columns:
    print("\n✅ Raw file HAS ' Appointment State' column")
elif 'Appointment State' in df_raw.columns:
    print("\n✅ Raw file HAS 'Appointment State' column")
else:
    print("\n❌ Raw file DOES NOT have Appointment State column")
    if 'Patient State' in df_raw.columns:
        print("   But it HAS 'Patient State' column")
    if 'Appointment Provider Name' in df_raw.columns:
        print("   And it HAS 'Appointment Provider Name' column")



