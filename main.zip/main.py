import os
import json
import shutil
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime

# Import processing and upload modules
try:
    from process_data import generate_healthx_import
    from upload_hx import hx_upload
except ImportError as e:
    print(f"Warning: Could not import modules: {e}")


def _ensure_dirs(cfg: dict) -> tuple[str, str, str]:
    """Create input, output, and log directories if they don't exist."""
    base = os.getcwd()
    in_dir = os.path.join(base, cfg.get("input_folder", "inputs"))
    out_dir = os.path.join(base, cfg.get("output_folder", "outputs"))
    log_dir = os.path.join(base, cfg.get("log_folder", "logs"))
    for d in (in_dir, out_dir, log_dir):
        os.makedirs(d, exist_ok=True)
    return in_dir, out_dir, log_dir


def _load_config() -> dict:
    """Load configuration from config.json."""
    cfg_path = os.path.join(os.getcwd(), "config.json")
    try:
        with open(cfg_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        return {}


# Global variable to store current run's log file path
_current_log_path = None

def _log(message: str, log_path: str = None) -> None:
    """Write message to log file with timestamp."""
    global _current_log_path
    
    if log_path:
        _current_log_path = log_path
    elif _current_log_path is None:
        # Create new log file if none exists
        cfg = _load_config()
        _, _, log_dir = _ensure_dirs(cfg)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        _current_log_path = os.path.join(log_dir, f"run_{ts}.txt")
    
    with open(_current_log_path, "a", encoding="utf-8") as f:
        log_ts = datetime.now().strftime("%H:%M:%S")
        f.write(f"[{log_ts}] {message}\n")


def run_process_async(ecw_path: str, template_path: str, status_label: tk.Label, root: tk.Tk) -> None:
    """Run the complete automation workflow in a separate thread."""
    try:
        cfg = _load_config()
        in_dir, out_dir, log_dir = _ensure_dirs(cfg)
        
        # Initialize log file for this run (create single log file for entire run)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_log_path = os.path.join(log_dir, f"run_{ts}.txt")
        _log("=" * 60, log_path=run_log_path)
        _log("Audentes Verification Automation Tool - Run Started", log_path=run_log_path)
        _log("=" * 60, log_path=run_log_path)

        # Step 1: Save files to inputs/ folder
        status_label.config(text="Saving files to inputs/ folder...")
        root.update()
        
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        ecw_copy = os.path.join(in_dir, f"eCW_{ts}{os.path.splitext(ecw_path)[1]}")
        tpl_copy = os.path.join(in_dir, f"Template_{ts}{os.path.splitext(template_path)[1]}")
        shutil.copy2(ecw_path, ecw_copy)
        shutil.copy2(template_path, tpl_copy)
        
        _log(f"eCW file loaded: {os.path.basename(ecw_copy)}", log_path=run_log_path)
        _log(f"Template file loaded: {os.path.basename(tpl_copy)}", log_path=run_log_path)
        
        # Step 2: Process data
        status_label.config(text="Processing data... Please wait.")
        root.update()
        
        try:
            output_path, processed_count = generate_healthx_import(ecw_copy, tpl_copy, log_path=run_log_path)
            _log(f"Data filtered successfully. {processed_count} records remaining.", log_path=run_log_path)
            _log(f"Output saved: {os.path.basename(output_path)}", log_path=run_log_path)
        except Exception as e:
            error_msg = f"Data processing failed: {str(e)}"
            _log(f"ERROR: {error_msg}", log_path=run_log_path if 'run_log_path' in locals() else None)
            messagebox.showerror("Processing Error", f"❌ {error_msg}\n\nCheck logs for details.")
            status_label.config(text="Processing failed. See logs.")
            return

        # Step 3: Upload to HealthX
        status_label.config(text="Uploading to HealthX portal...")
        root.update()
        
        try:
            success, upload_message = hx_upload(output_path, log_path=run_log_path)
            if success:
                _log(f"Upload to HealthX successful.", log_path=run_log_path)
                status_label.config(text="✅ Process Complete! Upload successful.")
                messagebox.showinfo(
                    "Audentes Automation Tool",
                    f"✅ Process Complete!\n\n"
                    f"• Processed {processed_count} records\n"
                    f"• Output file: {os.path.basename(output_path)}\n"
                    f"• Upload to HealthX: Successful\n\n"
                    f"Check logs folder for details."
                )
            else:
                _log(f"Upload to HealthX failed: {upload_message}", log_path=run_log_path)
                status_label.config(text="⚠️ Processing complete, but upload failed.")
                messagebox.showwarning(
                    "Upload Warning",
                    f"⚠️ Data processed successfully, but upload failed:\n\n{upload_message}\n\n"
                    f"Output file saved to:\n{output_path}\n\n"
                    f"You can upload manually or check logs."
                )
        except Exception as e:
            error_msg = f"Upload failed: {str(e)}"
            _log(f"ERROR: {error_msg}", log_path=run_log_path if 'run_log_path' in locals() else None)
            status_label.config(text="⚠️ Processing complete, but upload failed.")
            messagebox.showwarning(
                "Upload Error",
                f"⚠️ Data processed successfully, but upload failed:\n\n{error_msg}\n\n"
                f"Output file saved to:\n{output_path}\n\n"
                f"Check logs for details."
            )
            
    except Exception as exc:
        error_msg = f"Unexpected error: {str(exc)}"
        _log(f"FATAL ERROR: {error_msg}", log_path=run_log_path if 'run_log_path' in locals() else None)
        messagebox.showerror("Audentes Automation Tool", f"❌ {error_msg}\n\nSee logs folder for details.")
        status_label.config(text="Error occurred. See logs.")


def on_run_click(ecw_var: tk.StringVar, tpl_var: tk.StringVar, status_label: tk.Label, root: tk.Tk) -> None:
    """Validate inputs and start the automation process."""
    ecw_path = ecw_var.get().strip()
    template_path = tpl_var.get().strip()

    if not ecw_path or not os.path.isfile(ecw_path):
        messagebox.showwarning("Input Required", "Please select a valid eCW report (.xlsx/.xlsm/.csv).")
        return
    if not template_path or not os.path.isfile(template_path):
        messagebox.showwarning("Input Required", "Please select a valid template (.xlsx/.xlsm).")
        return

    # Disable the button during processing
    status_label.config(text="Starting process...")
    
    # Run in separate thread to avoid freezing GUI
    t = threading.Thread(target=run_process_async, args=(ecw_path, template_path, status_label, root), daemon=True)
    t.start()


def build_gui() -> None:
    """Build and display the main GUI window."""
    # Ensure working directory is the app folder (works for both script and frozen exe)
    base_dir = os.path.dirname(os.path.abspath(getattr(sys, 'frozen', False) and sys.executable or __file__))
    os.chdir(base_dir)
    
    # Ensure folders exist on startup
    cfg = _load_config()
    _ensure_dirs(cfg)

    root = tk.Tk()
    root.title("Audentes Verification Automation")
    root.geometry("700x300")

    # Header
    header = tk.Label(root, text="Audentes Verification Automation Tool", font=("Arial", 14, "bold"))
    header.grid(row=0, column=0, columnspan=3, padx=10, pady=15)

    ecw_var = tk.StringVar()
    tpl_var = tk.StringVar()

    def browse_ecw():
        path = filedialog.askopenfilename(title="Select eCW Report", filetypes=[("Data files", "*.xlsx *.xls *.xlsm *.csv")])
        if path:
            ecw_var.set(path)
            # Display filename in status
            status_label.config(text=f"Selected: {os.path.basename(path)}")

    def browse_tpl():
        path = filedialog.askopenfilename(title="Select Template/Macro File", filetypes=[("Excel files", "*.xlsx *.xls *.xlsm")])
        if path:
            tpl_var.set(path)
            # Display filename in status
            status_label.config(text=f"Selected: {os.path.basename(path)}")

    # eCW row
    tk.Label(root, text="eCW Report (.xlsx/.xlsm/.csv):").grid(row=1, column=0, padx=10, pady=10, sticky="w")
    ecw_entry = tk.Entry(root, textvariable=ecw_var, width=60)
    ecw_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
    tk.Button(root, text="Select eCW Report", command=browse_ecw).grid(row=1, column=2, padx=10, pady=10)

    # Template row
    tk.Label(root, text="Template/Macro File (.xlsx/.xlsm):").grid(row=2, column=0, padx=10, pady=10, sticky="w")
    tpl_entry = tk.Entry(root, textvariable=tpl_var, width=60)
    tpl_entry.grid(row=2, column=1, padx=10, pady=10, sticky="ew")
    tk.Button(root, text="Select Template/Macro File", command=browse_tpl).grid(row=2, column=2, padx=10, pady=10)

    # Configure column weights for responsive layout
    root.columnconfigure(1, weight=1)

    # Status label
    status_label = tk.Label(root, text="Ready - Select files and click 'Run Process'", wraplength=600, justify="left")
    status_label.grid(row=3, column=0, columnspan=3, padx=10, pady=10, sticky="w")

    # Run Process button
    run_button = tk.Button(
        root, 
        text="Run Process", 
        command=lambda: on_run_click(ecw_var, tpl_var, status_label, root),
        font=("Arial", 11, "bold"),
        bg="#4CAF50",
        fg="white",
        padx=20,
        pady=5
    )
    run_button.grid(row=4, column=0, columnspan=3, padx=10, pady=15)

    root.mainloop()


if __name__ == "__main__":
    build_gui()
